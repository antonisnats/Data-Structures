package 3hErgasia;

public class Rectangle {
    private final int xmin;
    private final int xmax;
    private final int ymin;
    private final int ymax;

    public Rectangle(int xmin, int xmax, int ymin, int ymax) {
        this.xmin = xmin;
        this.xmax = xmax;
        this.ymin = ymin;
        this.ymax = ymax;
    }

    public int xmin() {
        return xmin;
    }

    public int ymin() {
        return ymin;
    }

    public int xmax() {
        return xmax;
    }

    public int ymax() {
        return ymax;
    }

    public boolean contains(Point p) {
        return p.x() >= xmin && p.x() <= xmax && p.y() >= ymin && p.y() <= ymax;
    }

    public boolean intersects(Rectangle that) {
        return this.xmin <= that.xmax() && this.xmax >= that.xmin() &&
                this.ymin <= that.ymax() && this.ymax >= that.ymin();
    }

    public double distanceTo(Point p) {
        double dx = Math.max(xmin - p.x(), 0);
        dx = Math.max(dx, p.x() - xmax);
        double dy = Math.max(ymin - p.y(), 0);
        dy = Math.max(dy, p.y() - ymax);
        return Math.sqrt(dx * dx + dy * dy);
    }

    public int squareDistanceTo(Point p) {
        double dx = Math.max(xmin - p.x(), 0);
        dx = Math.max(dx, p.x() - xmax);
        double dy = Math.max(ymin - p.y(), 0);
        dy = Math.max(dy, p.y() - ymax);
        return (int) (dx * dx + dy * dy);
    }

    public String toString() {
        return "[" + xmin + ", " + xmax + "] x [" + ymin + ", " + ymax + "]";
    }
}
