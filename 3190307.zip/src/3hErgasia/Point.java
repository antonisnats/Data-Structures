package 3hErgasia;

public class Point {
    private int x;
    private int y;

    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int x() {
        return x;
    }

    public int y() {
        return y;
    }

    public double distanceTo(Point z) {
        int dx = x - z.x();
        int dy = y - z.y();
        return Math.sqrt(dx*dx + dy*dy);
    }

    public int squareDistanceTo(Point z) {
        int dx = x - z.x();
        int dy = y - z.y();
        return dx*dx + dy*dy;
    }

    public String toString() {
        return "(" + x + ", " + y + ")";
    }
}
