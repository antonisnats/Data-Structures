package 3hErgasia;

public class TreeNode {
    private Point item;
    private TreeNode l;
    private TreeNode r;
    
    public TreeNode(Point item) {
        this.item = item;
        this.l = null;
        this.r = null;
    }
    
    public Point getItem() {
        return item;
    }
    
    public TreeNode getLeft() {
        return l;
    }
    
    public TreeNode getRight() {
        return r;
    }
    
    public void setLeft(TreeNode left) {
        this.l = left;
    }
    
    public void setRight(TreeNode right) {
        this.r = right;
    }
}