package 3hErgasia;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TwoDTree {

    private class TreeNode {
        private Point point;
        private TreeNode left;
        private TreeNode right;
		public boolean isVertical;

        public TreeNode(Point point) {
            this.point = point;
            left = null;
            right = null;
        }
    };

    private TreeNode head;
    private int size;

    public TwoDTree() {
        head = null;
        size = 0;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    public void insert(Point p) {
        head = insert(head, p, true);
    }

    private TreeNode insert(TreeNode node, Point p, boolean isVertical) {
        if (node == null) {
            size++;
            return new TreeNode(p);
        }
        if (node.point.equals(p)) {
            return node;
        }
        if (isVertical) {
            if (p.x() < node.point.x()) {
                node.left = insert(node.left, p, !isVertical);
            } else {
                node.right = insert(node.right, p, !isVertical);
            }
        } else {
            if (p.y() < node.point.y()) {
                node.left = insert(node.left, p, !isVertical);
            } else {
                node.right = insert(node.right, p, !isVertical);
            }
        }
        return node;
    }

    public boolean search(Point p) {
        return search(head, p, true);
    }

    private boolean search(TreeNode node, Point p, boolean isVertical) {
        if (node == null) {
            return false;
        }
        if (node.point.equals(p)) {
            return true;
        }
        if (isVertical) {
            if (p.x() < node.point.x()) {
                return search(node.left, p, !isVertical);
            } else {
                return search(node.right, p, !isVertical);
            }
        } else {
            if (p.y() < node.point.y()) {
                return search(node.left, p, !isVertical);
            } else {
                return search(node.right, p, !isVertical);
            }
        }
    }

    public Point nearestNeighbor(Point p) {
        if (isEmpty()) {
            return null;
        }
        TreeNode closestNode = nearestNeighborHelper(head, p, head.point);
        return closestNode.point;
    }

    private TreeNode nearestNeighborHelper(TreeNode node, Point target, Point closest) {
        if (node == null) {
            return new TreeNode(closest);
        }
        if (node.point.distanceTo(target) < closest.distanceTo(target)) {
            closest = node.point;
        }
        double distToTarget = target.distanceTo(node.point);
        double distToClosest = target.distanceTo(closest);

        if (distToTarget < distToClosest) {
            if (node.point.x() > target.x()) {
                closest = nearestNeighborHelper(node.left, target, closest).point;
                if (node.right != null && target.distanceTo(closest) > target.distanceTo(new Point(node.point.x(), target.y()))) {
                    closest = nearestNeighborHelper(node.right, target, closest).point;
                }
            } else {
                closest = nearestNeighborHelper(node.right, target, closest).point;
                if (node.left != null && target.distanceTo(closest) > target.distanceTo(new Point(node.point.x(), target.y()))) {
                    closest = nearestNeighborHelper(node.left, target, closest).point;
                }
            }
        } else {
            if (node.point.x() > target.x()) {
                closest = nearestNeighborHelper(node.left, target, closest).point;
            } else {
                closest = nearestNeighborHelper(node.right, target, closest).point;
            }
        }
        return new TreeNode(closest);
    }
    
    public List<Point> rangeSearch(Rectangle rect) {
        List<Point> pointsInRange = new ArrayList<>();
        range(head, rect, pointsInRange);
        return pointsInRange;
    }

    private void range(TreeNode node, Rectangle rect, List<Point> pointsInRange) {
        if (node == null) {
            return;
        }

        if (rect.contains(node.point)) {
            pointsInRange.add(node.point);
        }

        if (node.isVertical) {
            if (node.point.x() > rect.xmin()) {
                range(node.left, rect, pointsInRange);
            }
            if (node.point.x() <= rect.xmax()) {
                range(node.right, rect, pointsInRange);
            }
        } else {
            if (node.point.y() > rect.ymin()) {
                range(node.left, rect, pointsInRange);
            }
            if (node.point.y() <= rect.ymax()) {
                range(node.right, rect, pointsInRange);
            }
        }
    }
    
    public static void main(String[] args) {
        String filename = args[0];
        Scanner in;
		try {
            in = new Scanner(new File(filename));
        } catch (FileNotFoundException e) {
            System.out.println("File not found!");
            return;
        }

        int N = in.nextInt(); // posa shmeia vriskontai sto arxeio
        TwoDTree tree = new TwoDTree();
        for (int i = 0; i < N; i++) {
            int x = in.nextInt();
            int y = in.nextInt();
            if (x < 0 || x > 100 || y < 0 || y > 100) {
                System.out.println("Invalid input! Coordinates must be between 0 and 100.");
                return;
            }
            tree.insert(new Point(x,y));
        }

        Scanner input = new Scanner(System.in);
        while (true) {
            System.out.println("Choose an option:");
            System.out.println("1. Compute the size of the tree");
            System.out.println("2. Insert a new point");
            System.out.println("3. Search if a given point exists in the tree");
            System.out.println("4. Provide a query rectangle");
            System.out.println("5. Provide a query point");
            int option = input.nextInt();
            switch (option) {
                case 1:
                    System.out.println("Size of the tree: " + tree.size());
                    break;
                case 2:
                    System.out.print("Enter x and y coordinates of the point to insert: ");
                    int x = input.nextInt();
                    int y = input.nextInt();
                    if (x < 0 || x > 100 || y < 0 || y > 100) {
                        System.out.println("Invalid input! Coordinates must be between 0 and 100.");
                        break;
                    }
                    tree.insert(new Point(x,y));
                    System.out.println("Point (" + x + ", " + y + ") inserted.");
                    break;
                case 3:
                    System.out.print("Enter x and y coordinates of the point to search: ");
                    x = input.nextInt();
                    y = input.nextInt();
                    if (x < 0 || x > 100 || y < 0 || y > 100) {
                        System.out.println("Invalid input! Coordinates must be between 0 and 100.");
                        break;
                    }
                    if (tree.search(new Point(x,y))) {
                        System.out.println("Point (" + x + ", " + y + ") exists in the tree.");
                    } else {
                        System.out.println("Point (" + x + ", " + y + ") does not exist in the tree.");
                    }
                    break;
                case 4:
                    System.out.print("Enter x and y coordinates of the bottom-left and top-right corners of the query rectangle: ");
                    int x1 = input.nextInt();
                    int y1 = input.nextInt();
                    break;
                   
                case 5: 
                    int x2, y2;
                    System.out.println("Enter the x coordinate of the point:");
                    x2 = in.nextInt();
                    System.out.println("Enter the y coordinate of the point:");
                    y2 = in.nextInt();
                    Point searchPoint = new Point(x2, y2);
                    if (tree.search(searchPoint)) {
                        System.out.println("The point exists in the tree");
                    } else {
                        System.out.println("The point does not exist in the tree");
                    }
                    break;

                 
            }
        }
    }
}
        
