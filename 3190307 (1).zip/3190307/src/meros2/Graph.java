package javaapplication30;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Graph {
    //οΙ ΔΙΑΣΤΑΣΕΙΣ ΤΟΥ ΛΑΒΥΡΙΝΘΟΥ
    private int cols;
    private int rows;
    //Ο ΠΙΝΑΚΑΣ ΠΟΥ ΑΝΤΙΣΤΟΙΧΕΙ ΣΤΟ ΛΑΒΥΡΙΝΘΟ
    private int matrix[][];
    //ΟΙ ΣΥΝΤΕΤΑΓΜΕΝΕΣ ΕΙΣΟΔΟΥ ΣΤΟ ΛΑΒΥΡΙΝΘΟ
    private int entranceX;
    private int entranceY;

    public Graph(String filename) throws Exception {
        try {
            //ΔΙΑΒΑΖΟΝΤΑΙ ΤΑ ΣΤΟΙΧΕΙΑ ΤΟΥ ΛΑΒΥΡΙΝΘΟΥ ΑΠΟ ΤΟ ΑΡΧΕΙΟ FILENAME
            File file = new File(filename);     
            FileReader fr = new FileReader(file);   
            BufferedReader br = new BufferedReader(fr);  
            StringBuffer sb = new StringBuffer();     
            String line;
            int count = 0;
            while ((line = br.readLine()) != null) {
                String elems[];
                //ΔΙΑΒΑΖΕΙ ΤΟ ΜΕΓΕΘΟΣ ΤΟΥ ΛΑΒΥΡΙΝΘΟΥ
                if (count == 0){
                    elems = line.split(" ");
                    this.rows = Integer.parseInt(elems[0]);
                    this.cols = Integer.parseInt(elems[1]);
                    this.matrix = new int[this.rows][this.cols];
                }
                //ΔΙΑΒΑΖΕΙ ΤΟ ΣΗΜΕΙΟ ΕΙΣΟΔΟΥ
                else if (count == 1){
                    elems = line.split(" ");
                    this.entranceX = Integer.parseInt(elems[0]);
                    this.entranceY = Integer.parseInt(elems[1]);
                    System.out.println(this.entranceX+ "  " +this.entranceY);
                }
                //ΔΙΑΒΑΖΕΙ ΤΗΝ ΑΝΑΠΑΡΑΣΤΑΣΗ ΤΟΥ ΛΑΒΥΡΙΝΘΟΥ
                else {
                    elems = line.split(" ");
                    System.out.println(line);
                    for (int i=0;i<this.cols;i++){
                        if (!(((count - 2)==this.entranceX) && (i==this.entranceY))){
                            this.matrix[count - 2][i] = Integer.parseInt(elems[i]);
                        }
                        else {
                            this.matrix[count - 2][i] = 2;
                        }
                        
                    }
                }
                count++;
            }
            fr.close();      
        } catch (Exception e) {
            System.out.println("Σφάλμα κατά την ανάγνωση του αρχείου!");
            throw (new Exception());
        }
    }
    //ΒΡΙΣΚΕΙ ΤΑ ΠΡΟΣΒΑΣΙΜΑ ΓΕΙΤΟΝΙΚΑ ΚΕΛΙΑ ΤΟΥ
    //ΚΕΛΙΟΥ ΠΟΥ ΠΡΟΣΔΙΟΡΙΖΕΤΑΙ ΜΕ ΤΗ 
    //ΣΥΜΒΟΛΟΣΕΙΡΑ xy
    String[] neighboors(String xy){
        //ΛΑΜΒΑΝΟΝΤΑΙ ΟΙ ΣΥΝΤΕΤΑΓΜΕΝΕΣ ΑΠΟ ΤΗ ΣΥΜΒΟΛΟΣΕΙΡΆ
        String[] elems = xy.split("-");
        int x = Integer.parseInt(elems[0]);
        int y = Integer.parseInt(elems[1]);
        String[] N = {"","","",""};
        int i = 0;
        //ΕΛΕΓΧΟΝΤΑΙ ΟΙ ΓΕΙΤΟΝΕΣ
        //ΔΕΝ ΕΛΕΓΧΟΝΤΑΙ ΟΙ ΔΙΑΓΩΝΙΟΙ
        for (int r = x-1; r<x+2; r++){
            for (int c = y-1; c<y+2; c++){
                if ((r>=0) && (r<this.rows) && (c>=0) && (c<this.cols)){
                    if ((r-x)*(c-y)==0){//ΑΠΟΤΡΟΠΗ ΕΛΕΓΧΟΥ ΔΙΑΓΩΝΙΏΝ ΓΕΙΤΟΝΩΝ
                        if (this.matrix[r][c]==0){
                            N[i++] = r+"-"+c;
                        }
                    }
                }
            }
        }
        return N;
    }
    //ΕΞΕΡΕΥΝΗΣΗ ΤΟΥ ΛΑΒΥΡΙΝΘΟΥ
    String DFS(){
        StringStackImpl S = new StringStackImpl();
        //ΑΦΕΤΗΡΙΑ - ΕΙΣΑΓΕΤΑΙ ΣΤΗ ΣΤΟΙΒΑ
        String s = this.entranceX+"-"+this.entranceY;
        S.push(s);
        while (!S.isEmpty()){
            //ΕΞΑΓΩΓΗ ΑΠΟ ΤΗ ΣΤΟΙΒΑ
            String current = S.pop();
            String[] elems = current.split("-");
            //ΣΗΜΑΝΣΗ ΤΟΥ ΚΕΛΙΟΥ ΣΑΝ ΚΑΠΟΙΟ ΠΟΥ ΕΧΕΙ ΗΔΗ ΕΛΕΓΧΘΕΙ
            this.matrix[Integer.parseInt(elems[0])][Integer.parseInt(elems[1])] = 2;
            //ΑΝ ΦΘΑΣΑΜΕ ΣΕ ΣΗΜΕΙΟ ΕΞΟΔΟΥ
            if (!current.equals(s)){
                if ((elems[0].equals("0"))||(elems[1].equals("0")||Integer.parseInt(elems[0])==(this.rows-1) || Integer.parseInt(elems[1])==(this.cols-1))){
                    //ΕΠΙΣΤΡΕΦΟΝΤΑΙ ΟΙ ΣΥΝΤΕΤΑΓΜΕΝΕΣ ΤΟΥ ΣΗΜΕΙΟΥ ΕΞΟΔΟΥ
                    return "ΣΗΜΕΙΟ ΕΞΟΔΟΥ: ΓΡΑΜΜΗ "+elems[0]+" ΣΤΗΛΗ "+elems[1];
                }
            }
            //ΕΝΤΟΠΙΖΟΝΤΑΙ ΟΙ ΓΕΙΤΟΝΕΣ ΤΟΥ ΤΡΕΧΟΝΤΟΣ ΚΕΛΙΟΥ
            String[] n = this.neighboors(current);
            int i = 0;
            //ΕΙΣΑΓΟΝΤΑΙ ΟΙ ΓΕΙΤΟΝΕΣ ΣΤΗ ΣΤΟΙΒΑ
            while (n[i].length()>0){
                S.push(n[i]);
                i++;
                if (i==4){
                    break;
                }
            }
        }
        return "ΔΕΝ ΒΡΕΘΗΚΕ ΚΑΜΙΑ ΕΞΟΔΟΣ";
    }
    
}
