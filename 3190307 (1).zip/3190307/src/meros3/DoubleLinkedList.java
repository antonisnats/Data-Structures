package javaapplication30;

import java.io.PrintStream;
import java.util.HashSet;
import java.util.Set;

public class DoubleLinkedList<T> {
    private DLNode<T> head; //ΔΕΙΚΤΗΣ ΠΟΥ ΔΕΙΧΝΕΙ ΣΤΗΝ ΑΡΧΗ ΤΗΣ ΛΙΣΤΑΣ
    private int elements = 0; //Ο ΑΡΙΘΜΟΣ ΤΩΝ ΚΟΜΒΩΝ ΤΗΣ ΛΙΣΤΑΣ

    //ΚΑΤΑΣΚΕΥΑΣΤΗΣ 
    public DoubleLinkedList(DLNode<T> head) {
        this.head = head;
    }
    //GETTERS - SETTERS
    public DLNode<T> getHead() {
        return head;
    }

    public void setHead(DLNode<T> head) {
        this.head = head;
    }

    public int getElements() {
        return elements;
    }

    public void setElements(int elements) {
        this.elements = elements;
    }
    //ΕΠΙΣΤΡΕΦΕΙ TRUE ΑΝ Η ΛΙΣΤΑ ΕΙΝΑΙ ΚΕΝΗ
    public boolean isEmpty(){
        return ((head == null) );
    }
    //ΕΙΣΑΓΩΓΗ ΚΟΜΒΟΥ ΣΤΗ ΛΙΣΤΑ
    public void insert(DLNode<T> x){
        //ΑΝ Η ΛΙΣΤΑ ΕΙΝΑΙ ΚΕΝΗ
        if (isEmpty()){
            //Ο ΕΙΣΕΡΧΟΜΕΝΟΣ ΚΟΜΒΟΣ ΔΕΙΧΝΕΙ ΣΑΝ ΕΠΟΜΕΝΟ
            //ΚΑΙ ΠΡΟΗΓΟΥΜΕΝΟ ΤΟΝ ΕΑΥΤΌ ΤΟΥ
            x.setNext(x);
            x.setPrevious(x);
            this.head = x;
        }
        else {
            //ΠΑΡΕΜΒΆΕΤΑΙ ΜΕΤΑΞΥ ΤΟΥ ΠΡΩΤΟΥ ΚΑΙ ΤΟΥ ΤΕΛΕΥΤΑΙΟΥ Ο ΝΕΟΣ ΚΟΜΒΟΣ
            if (elements==1){
                System.out.println("One Element");
                this.head.setNext(x);
                x.setNext(this.head);
                
                this.head.setPrevious(x);
                x.setPrevious(this.head);
            
            }
            else {
                this.head.getPrevious().setNext(x);
                x.setNext(this.head);
                x.setPrevious(this.head.getPrevious());
                this.head.setPrevious(x);
            }
        }
        //ΑΥΞΑΝΕΤΑΙ Ο ΑΡΙΘΜΟΣ ΤΩΝ ΑΠΟΘΗΚΕΥΜΈΝΩΝ ΚΟΜΒΩΝ
        elements++;
    }
    
    public DLNode remove(){
        //ΑΝ Η ΣΤΟΙΒΑ ΕΙΝΑΙ ΚΕΝΗ ΕΠΙΣΤΡΈΦΕΙ NULL
        if (isEmpty()){
            return null;
        }
        else if (elements == 1){
            DLNode temp = this.head;
            this.head = null;
            elements--;
            return temp;
        }
        else {
            //ΑΠΟΜΑΚΡΎΝΕΤΑΙ Ο ΠΡΩΤΟΣ ΚΟΜΒΟΣ ΚΑΙ ΑΠΟΚΑΘΙΣΤΑΝΤΑΙ ΟΙ ΔΕΙΚΤΕΣ
            DLNode temp = this.head;
            this.head.getPrevious().setNext(this.head.getNext());
            this.head.getNext().setPrevious(this.head.getPrevious());
            this.head = this.head.getNext();
            elements--;
            return temp;
        }
        
    }
    //ΕΚΤΥΠΩΣΗ ΤΩΝ ΠΕΡΙΕΧΟΜΕΝΩΝ ΤΗΣ ΛΙΣΤΑΣ
    public void printList(PrintStream p){
        DLNode temp;
        temp = this.head;
        if (temp!=null){
            p.print(" - "+((String)temp.getData())+" - ");
        }
        temp = temp.getNext();
        while (temp!=this.head){
            p.print(" - "+((String)temp.getData())+" - ");
            temp = temp.getNext();
        }
    }
}
