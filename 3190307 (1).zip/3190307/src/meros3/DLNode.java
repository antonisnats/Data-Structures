
package javaapplication30;

public class DLNode<T>{
    private DLNode previous;//Ο ΠΡΟΗΓΟΥΜΕΝΟΣ ΤΟΥ ΚΟΜΒΟΥ
    private DLNode next; // Ο ΕΠΟΜΕΝΟΣ ΤΟΥ ΚΟΜΒΟΥ
    private T data; //ΤΑ ΔΕΔΟΜΕΝΑ ΤΟΥ ΚΟΜΒΟΥ

    //ΚΑΤΑΣΚΕΥΑΣΤΗΣ
    public DLNode(DLNode previous, DLNode next, T data) {
        this.previous = previous;
        this.next = next;
        this.data = data;
    }
    //GETTERS - SETTERS
    public DLNode getPrevious() {
        return previous;
    }

    public void setPrevious(DLNode previous) {
        this.previous = previous;
    }

    public DLNode getNext() {
        return next;
    }

    public void setNext(DLNode next) {
        this.next = next;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
    
}
