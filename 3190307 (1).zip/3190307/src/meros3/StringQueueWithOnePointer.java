
package javaapplication30;

import java.io.PrintStream;
import java.util.NoSuchElementException;

public class StringQueueWithOnePointer implements StringQueue{
    //ΔΙΠΛΑ ΣΥΝΔΕΔΕΜΕΝΗ ΚΥΚΛΙΚΗ ΛΙΣΤΑ
    public DoubleLinkedList<String> LIST;
    public StringQueueWithOnePointer() {
        LIST = new DoubleLinkedList<String>(null);
    }
    
    
    
    @Override
    public boolean isEmpty() {
        return this.LIST.isEmpty();
    }

    @Override
    public void put(String item) {
        DLNode D = new DLNode<String>(null, null, item);
        this.LIST.insert(D);
    }


    @Override
    public String get() throws NoSuchElementException {
        if (isEmpty()){
            throw new NoSuchElementException();
        }
        return (String)(this.LIST.remove().getData());
    }

    @Override
    public String peek() throws NoSuchElementException {
        if (isEmpty()){
            throw new NoSuchElementException();
        }
        return (String)(this.LIST.getHead().getData());
    }

    @Override
    public void printQueue(PrintStream stream) {
        this.LIST.printList(stream);
        
    }

    @Override
    public int size() {
        return this.LIST.getElements();
    }
    
}
