package javaapplication30;

import java.io.PrintStream;

public class LinkedList<T> {
    private Node<T> head; //ΑΡΧΗ ΤΗΣ ΛΙΣΤΑΣ
    private Node<T> tail; //ΤΕΛΟΣ ΤΗΣ ΣΙΣΤΑΣ 
    private int elements = 0; //ΑΡΙΘΜΟΣ ΚΟΜΒΩΝ ΣΤΗ ΛΙΣΤΑ
    //ΚΑΤΑΣΚΕΥΑΣΤΗΣ ΤΗΣ ΛΙΣΤΑΣ
    public LinkedList(Node<T> head, Node<T> tail) {
        this.head = head;
        this.tail = tail;
        this.elements = 0;
    }
    //SETTERS KAI GETTERS
    public Node<T> getHead() {
        return head;
    }

    public void setHead(Node<T> head) {
        this.head = head;
    }

    public Node getTail() {
        return tail;
    }

    public void setTail(Node<T> tail) {
        this.tail = tail;
    }

    public int getElements() {
        return elements;
    }

    public void setElements(int elements) {
        this.elements = elements;
    }
    
    
    
    public boolean isEmpty(){
        return ((head == null) && (tail == null));
    }
    //ΕΙΣΑΓΩΓΗ ΤΟΥ ΚΟΜΒΟΥ X ΣΤΗΝ ΑΡΧΗ Η ΤΟ ΤΕΛΟΣ ΤΗΣ ΛΙΣΤΑΣ 
    //ΑΝΑΛΟΓΑ ΜΕ ΤΗΝ ΤΙΜΗ ΤΟΥ WHERE
    public void insert(Node<T> x, String where){
        //AN H ΛΙΣΤΑ ΕΙΝΑΙ ΚΕΝΗ ΚΑΙ ΟΙ ΔΥΟ ΔΕΙΚΤΕΣ ΔΕΙΧΝΟΥΝ ΤΟ ΝΕΟ ΚΟΜΒΟ
        if (isEmpty()){
            System.out.println("FIRST");
            this.head = x;
            this.tail = x;
        }
        else {
            //ΕΙΣΑΓΩΓΗ ΣΤΗΝ ΑΡΧΗ
            if (where.equals("FRONT")){
                x.setNext(this.head);
                this.setHead(x);
            }
            //ΕΙΣΑΓΩΓΗ ΣΤΟ ΤΕΛΟΣ
            else if (where.equals("TAIL")){
                this.tail.setNext(x);
                x.setNext(null);
                this.tail = x;
                
            }
        }
        //Ο ΑΡΙΘΜΟΣ ΤΩΝ ΣΤΟΙΧΕΙΩΝ ΑΥΞΑΝΕΤΑΙ ΚΑΤΑ ΕΝΑ
        elements++;
    }
    //ΑΠΟΣΥΡΕΤΑΙ ΣΤΟΙΧΕΊΟ ΑΠΟ ΤΗ ΛΙΣΤΑ (ΠΑΝΤΑ ΤΟ ΤΕΛΕΥΤΑΙΟ)
    public Node remove(){
        //ΑΝ Η ΛΙΣΤΑ ΕΙΝΑΙ ΚΕΝΗ ΕΠΙΣΤΡΕΦΕΙ NULL
        if (isEmpty()){
            return null;
        }
        else {
            //ΑΦΑΙΡΕΙΤΑΙ ΤΟ ΠΡΩΤΟ ΣΤΟΙΧΕΙΟ ΤΗΣ ΛΙΣΤΑΣ
            Node temp = this.head;
            this.head = this.head.getNext();
            this.elements--;
            if (this.elements == 0){
                this.head = null;
            }
            return temp;
        }
    }
    //ΕΚΤΥΠΩΣΗ ΤΗΣ ΛΙΣΤΑΣ
    public void printList(PrintStream p){
        Node temp = this.head;
        while (temp!=null){
            p.print(" - " + temp.getData().toString() + " - ");
            temp = temp.getNext();
        }
        p.println("");
    }
}
