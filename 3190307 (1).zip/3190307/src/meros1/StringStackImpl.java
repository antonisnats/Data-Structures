package javaapplication30;


import java.io.PrintStream;
import java.util.NoSuchElementException;

public class StringStackImpl implements StringStack{
    public LinkedList<String> LIST;
    public StringStackImpl() {
        LIST = new LinkedList<String>(null, null);
    }

    @Override
    public boolean isEmpty() {
        return this.LIST.isEmpty();
    }

    @Override
    public void push(String item) {
        //ΕΙΣΑΓΩΣΗ ΣΤΟ ΤΕΛΟΣ ΤΗΣ ΛΙΣΤΑΣ
        this.LIST.insert(new Node<String>(item,null), "FRONT");
    }

    @Override
    public String pop() throws NoSuchElementException {
        if (isEmpty()){
            throw new NoSuchElementException();
        }
        return (String)(this.LIST.remove().getData());
    }

    @Override
    public String peek() throws NoSuchElementException {
        if (isEmpty()){
            throw new NoSuchElementException();
        }
        return (String)(this.LIST.getTail().getData());
    }

    @Override
    public void printStack(PrintStream stream) {
       this.LIST.printList(stream);
    }

    @Override
    public int size() {
        return this.LIST.getElements();
    }
    
    
}
