
package javaapplication30;

import java.io.PrintStream;
import java.util.NoSuchElementException;


public class StringQueueImpl implements StringQueue{
    //ΛΙΣΤΑ ΠΟΥ ΥΛΟΠΟΙΕΊ ΤΗΝ ΟΥΡΑ
    public LinkedList<String> LIST;
    public StringQueueImpl() {
        LIST = new LinkedList<String>(null, null);
    }
    
    //ΕΠΙΣΤΡΕΦΕΙ TRUE AN Η ΛΙΣΤΑ ΕΙΝΑΙ ΚΕΝΗ
    @Override
    public boolean isEmpty() {
        return this.LIST.isEmpty();
    }

    @Override
    public void put(String item) {
        //ΕΙΓΑΓΩΓΗ ΣΤο τελοσ ΤΗΣ ΛΙΣΤΑΣ
        this.LIST.insert(new Node<String>(item,null), "TAIL");
    }

    @Override
    public String get() throws NoSuchElementException {
        if (isEmpty()){
            throw new NoSuchElementException();
        }
        return (String)(this.LIST.remove().getData());
    }

    @Override
    public String peek() throws NoSuchElementException {
        if (isEmpty()){
            throw new NoSuchElementException();
        }
        return (String)(this.LIST.getTail().getData());
    }

    @Override
    public void printQueue(PrintStream stream) {
        this.LIST.printList(stream);
    }

    @Override
    public int size() {
        return this.LIST.getElements();
    }
    
}
